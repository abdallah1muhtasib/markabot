const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('box')
    .setDescription('Start an instant giveaway - first to react wins')
    .addStringOption(option =>
      option.setName('prize')
        .setDescription('Prize for the giveaway')
        .setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  async executeSlash(interaction, client) {
    const prize = interaction.options.getString('prize');

    const embed = new EmbedBuilder()
      .setTitle('<:emoji_7:1436089797654351904> INSTANT GIVEAWAY <:emoji_7:1436089797654351904>')
      .setDescription(`<:emoji_6:1436085002050732163> *Prize:* ${prize}\n\nFirst to react with <:emoji_7:1436089797654351904> wins!`)
      .setColor('#6A3FF2')
      .setFooter({ text: `Hosted by ${interaction.user.tag}` })
      .setTimestamp();

    await interaction.reply({ content: '✅ Instant giveaway created!', ephemeral: true });
    const giveawayMessage = await interaction.channel.send({ embeds: [embed] });
    await giveawayMessage.react('1436089797654351904');

    const filter = (reaction, user) => {
      return reaction.emoji.id === '1436089797654351904' && !user.bot;
    };

    const collector = giveawayMessage.createReactionCollector({ filter, max: 1, time: 60000 });

    collector.on('collect', async (reaction, user) => {
      const winEmbed = new EmbedBuilder()
        .setTitle('<:emoji_7:1436089797654351904> GIVEAWAY ENDED <:emoji_7:1436089797654351904>')
        .setDescription(`**Prize:** ${prize}\n**Winner:** <@${user.id}>`)
        .setColor('#FFD700')
        .setTimestamp();

      await giveawayMessage.edit({ embeds: [winEmbed] });
      await interaction.channel.send(`🎊 Congratulations <@${user.id}>! You won **${prize}**!`);
    });

    collector.on('end', async (collected) => {
      if (collected.size === 0) {
        const noWinnerEmbed = new EmbedBuilder()
          .setTitle('<:emoji_7:1436089797654351904> GIVEAWAY ENDED <:emoji_7:1436089797654351904>')
          .setDescription(`**Prize:** ${prize}\n**Winner:** No one entered!`)
          .setColor('#FF0000')
          .setTimestamp();

        await giveawayMessage.edit({ embeds: [noWinnerEmbed] });
      }
    });
  }
};
