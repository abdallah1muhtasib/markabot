const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('invites')
    .setDescription('Check invite points')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('The user to check (leave empty for yourself)')
        .setRequired(false)),

  async executeSlash(interaction, client) {
    const guildId = interaction.guild.id;
    const targetUser = interaction.options.getUser('user') || interaction.user;
    
    const userInvites = global.invites[guildId]?.[targetUser.id];
    const points = userInvites?.points || 0;
    const inviteCount = userInvites?.invites?.length || 0;

    await interaction.reply(`📊 **Invite Stats for ${targetUser.username}**\n\n⭐ Points: ${points}\n👥 Valid Invites: ${inviteCount}`);
  }
};
