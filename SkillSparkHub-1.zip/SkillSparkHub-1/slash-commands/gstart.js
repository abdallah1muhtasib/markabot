const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('gstart')
    .setDescription('Start a giveaway')
    .addStringOption(option =>
      option.setName('duration')
        .setDescription('Duration (e.g., 10s, 5m, 2h, 1d)')
        .setRequired(true))
    .addIntegerOption(option =>
      option.setName('winners')
        .setDescription('Number of winners')
        .setRequired(true)
        .setMinValue(1))
    .addStringOption(option =>
      option.setName('prize')
        .setDescription('Prize for the giveaway')
        .setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  async executeSlash(interaction, client) {
    const duration = interaction.options.getString('duration');
    const winnersCount = interaction.options.getInteger('winners');
    const prize = interaction.options.getString('prize');

    const timeMatch = duration.match(/^(\d+)([smhd])$/);
    if (!timeMatch) {
      return interaction.reply({ 
        content: '❌ Invalid duration format. Use: 10s, 5m, 2h, or 1d', 
        ephemeral: true 
      });
    }

    const timeValue = parseInt(timeMatch[1]);
    const timeUnit = timeMatch[2];
    const timeInMs = {
      's': timeValue * 1000,
      'm': timeValue * 60 * 1000,
      'h': timeValue * 60 * 60 * 1000,
      'd': timeValue * 24 * 60 * 60 * 1000
    }[timeUnit];

    const endTime = Date.now() + timeInMs;

    const embed = new EmbedBuilder()
      .setTitle('<:emoji_7:1436089797654351904> GIVEAWAY <:emoji_7:1436089797654351904>')
      .setDescription(`<:emoji_6:1436085002050732163> *Prize:* ${prize}\n<:emoji_4:1436084282392182907> *Winners:* ${winnersCount}\n<:emoji_5:1436084947063406713> *Ends:* <t:${Math.floor(endTime / 1000)}:R>\n\nReact with <:emoji_7:1436089797654351904> to enter!`)
      .setColor('#6A3FF2')
      .setFooter({ text: `Hosted by ${interaction.user.tag}` })
      .setTimestamp();

    await interaction.reply({ content: '✅ Giveaway created!', ephemeral: true });
    const giveawayMessage = await interaction.channel.send({ embeds: [embed] });
    await giveawayMessage.react('1436089797654351904');

    const giveaway = {
      messageId: giveawayMessage.id,
      channelId: interaction.channel.id,
      guildId: interaction.guild.id,
      prize: prize,
      winnersCount: winnersCount,
      endTime: endTime,
      hostId: interaction.user.id,
      ended: false
    };

    global.giveaways.push(giveaway);
    global.saveGiveaways();

    setTimeout(async () => {
      try {
        const channel = await client.channels.fetch(giveaway.channelId);
        const msg = await channel.messages.fetch(giveaway.messageId);
        const reaction = msg.reactions.cache.get('1436089797654351904');
        
        if (!reaction) {
          return channel.send('❌ No one entered the giveaway.');
        }

        const users = await reaction.users.fetch();
        const entries = users.filter(user => !user.bot);

        if (entries.size === 0) {
          return channel.send('❌ No valid entries for the giveaway.');
        }

        const winners = [];
        const entriesArray = Array.from(entries.values());
        
        for (let i = 0; i < Math.min(winnersCount, entriesArray.length); i++) {
          const randomIndex = Math.floor(Math.random() * entriesArray.length);
          winners.push(entriesArray[randomIndex]);
          entriesArray.splice(randomIndex, 1);
        }

        const winnerMentions = winners.map(w => `<@${w.id}>`).join(', ');
        
        const winEmbed = new EmbedBuilder()
          .setTitle('🎊 Giveaway Ended! 🎊')
          .setDescription(`**Prize:** ${prize}\n**Winners:** ${winnerMentions}`)
          .setColor('#FFD700')
          .setTimestamp();

        await channel.send({ content: `Congratulations ${winnerMentions}!`, embeds: [winEmbed] });

        const index = global.giveaways.findIndex(g => g.messageId === giveaway.messageId);
        if (index !== -1) {
          global.giveaways[index].ended = true;
          global.giveaways[index].winners = winners.map(w => w.id);
          global.saveGiveaways();
        }
      } catch (error) {
        console.error('Error ending giveaway:', error);
      }
    }, timeInMs);
  }
};
