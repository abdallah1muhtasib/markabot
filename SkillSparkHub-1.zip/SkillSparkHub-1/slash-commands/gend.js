const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('gend')
    .setDescription('End a giveaway early')
    .addStringOption(option =>
      option.setName('message_id')
        .setDescription('The message ID of the giveaway')
        .setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  async executeSlash(interaction, client) {
    const messageId = interaction.options.getString('message_id');
    
    const giveawayIndex = global.giveaways.findIndex(g => g.messageId === messageId && !g.ended);
    
    if (giveawayIndex === -1) {
      return interaction.reply({ 
        content: '❌ No active giveaway found with that message ID.', 
        ephemeral: true 
      });
    }

    const giveaway = global.giveaways[giveawayIndex];

    try {
      const channel = await client.channels.fetch(giveaway.channelId);
      const msg = await channel.messages.fetch(giveaway.messageId);
      const reaction = msg.reactions.cache.get('🎉');
      
      if (!reaction) {
        return interaction.reply({ 
          content: '❌ No one entered the giveaway.', 
          ephemeral: true 
        });
      }

      const users = await reaction.users.fetch();
      const entries = users.filter(user => !user.bot);

      if (entries.size === 0) {
        return interaction.reply({ 
          content: '❌ No valid entries for the giveaway.', 
          ephemeral: true 
        });
      }

      const winners = [];
      const entriesArray = Array.from(entries.values());
      
      for (let i = 0; i < Math.min(giveaway.winnersCount, entriesArray.length); i++) {
        const randomIndex = Math.floor(Math.random() * entriesArray.length);
        winners.push(entriesArray[randomIndex]);
        entriesArray.splice(randomIndex, 1);
      }

      const winnerMentions = winners.map(w => `<@${w.id}>`).join(', ');
      
      const winEmbed = new EmbedBuilder()
        .setTitle('🎊 Giveaway Ended! 🎊')
        .setDescription(`**Prize:** ${giveaway.prize}\n**Winners:** ${winnerMentions}`)
        .setColor('#FFD700')
        .setTimestamp();

      await channel.send({ content: `Congratulations ${winnerMentions}!`, embeds: [winEmbed] });

      global.giveaways[giveawayIndex].ended = true;
      global.giveaways[giveawayIndex].winners = winners.map(w => w.id);
      global.saveGiveaways();

      await interaction.reply({ 
        content: '✅ Giveaway ended successfully!', 
        ephemeral: true 
      });
    } catch (error) {
      console.error('Error ending giveaway:', error);
      await interaction.reply({ 
        content: '❌ Failed to end the giveaway.', 
        ephemeral: true 
      });
    }
  }
};
