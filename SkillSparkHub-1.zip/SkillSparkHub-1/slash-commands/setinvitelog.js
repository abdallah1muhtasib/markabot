const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setinvitelog')
    .setDescription('Set the invite log channel')
    .addChannelOption(option =>
      option.setName('channel')
        .setDescription('The channel for invite logs')
        .setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  async executeSlash(interaction, client) {
    const channel = interaction.options.getChannel('channel');

    if (!global.inviteConfig[interaction.guild.id]) {
      global.inviteConfig[interaction.guild.id] = {};
    }

    global.inviteConfig[interaction.guild.id].logChannelId = channel.id;
    global.saveInviteConfig();

    await interaction.reply(`✅ Invite log channel set to <#${channel.id}>`);
  }
};
