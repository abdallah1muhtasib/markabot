module.exports = {
  name: 'invites',
  description: 'فحص نقاط الدعوات',
  async execute(message, args, client) {
    const guildId = message.guild.id;
    const targetUser = message.mentions.users.first() || message.author;
    
    const userInvites = global.invites[guildId]?.[targetUser.id];
    const points = userInvites?.points || 0;
    const inviteCount = userInvites?.invites?.length || 0;

    message.reply(`📊 **إحصائيات الدعوات لـ ${targetUser.username}**\n\n⭐ النقاط: ${points}\n👥 الدعوات الصالحة: ${inviteCount}`);
  }
};
