const { PermissionFlagsBits, EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'gstart',
  description: 'بدء جيف اواي',
  permissions: PermissionFlagsBits.ManageGuild,
  async execute(message, args, client) {
    const duration = args[0];
    const winnersCount = parseInt(args[1]);
    const prize = args.slice(2).join(' ');

    if (!duration || !winnersCount || !prize) {
      return message.reply('❌ الاستخدام: `$gstart <المدة> <عدد الفائزين> <الجائزة>`\nمثال: `$gstart 1h 1 Discord Nitro`');
    }

    const timeMatch = duration.match(/^(\d+)([smhd])$/);
    if (!timeMatch) {
      return message.reply('❌ صيغة المدة غير صحيحة. استخدم: 10s, 5m, 2h, أو 1d');
    }

    const timeValue = parseInt(timeMatch[1]);
    const timeUnit = timeMatch[2];
    const timeInMs = {
      's': timeValue * 1000,
      'm': timeValue * 60 * 1000,
      'h': timeValue * 60 * 60 * 1000,
      'd': timeValue * 24 * 60 * 60 * 1000
    }[timeUnit];

    const endTime = Date.now() + timeInMs;

    const embed = new EmbedBuilder()
      .setTitle('<:emoji_7:1436089797654351904> GIVEAWAY <:emoji_7:1436089797654351904>')
      .setDescription(`<:emoji_6:1436085002050732163> *الجائزة:* ${prize}\n<:emoji_4:1436084282392182907> *الفائزين:* ${winnersCount}\n<:emoji_5:1436084947063406713> *ينتهي:* <t:${Math.floor(endTime / 1000)}:R>\n\nتفاعل بـ <:emoji_7:1436089797654351904> للدخول!`)
      .setColor('#6A3FF2')
      .setFooter({ text: `مستضاف بواسطة ${message.author.tag}` })
      .setTimestamp();

    const giveawayMessage = await message.channel.send({ embeds: [embed] });
    await giveawayMessage.react('1436089797654351904');

    const giveaway = {
      messageId: giveawayMessage.id,
      channelId: message.channel.id,
      guildId: message.guild.id,
      prize: prize,
      winnersCount: winnersCount,
      endTime: endTime,
      hostId: message.author.id,
      ended: false
    };

    global.giveaways.push(giveaway);
    global.saveGiveaways();

    setTimeout(async () => {
      try {
        const channel = await client.channels.fetch(giveaway.channelId);
        const msg = await channel.messages.fetch(giveaway.messageId);
        const reaction = msg.reactions.cache.get('1436089797654351904');
        
        if (!reaction) {
          return channel.send('❌ لا أحد دخل الجيف اواي.');
        }

        const users = await reaction.users.fetch();
        const entries = users.filter(user => !user.bot);

        if (entries.size === 0) {
          return channel.send('❌ لا يوجد مشاركين صالحين للجيف اواي.');
        }

        const winners = [];
        const entriesArray = Array.from(entries.values());
        
        for (let i = 0; i < Math.min(winnersCount, entriesArray.length); i++) {
          const randomIndex = Math.floor(Math.random() * entriesArray.length);
          winners.push(entriesArray.splice(randomIndex, 1)[0]);
        }

        const winnerMentions = winners.map(w => `<@${w.id}>`).join(', ');
        
        const winEmbed = new EmbedBuilder()
          .setTitle('🎉 انتهى الجيف اواي 🎉')
          .setDescription(`**الجائزة:** ${giveaway.prize}\n**الفائزين:** ${winnerMentions}`)
          .setColor('#FFD700')
          .setTimestamp();

        await msg.edit({ embeds: [winEmbed] });
        await channel.send(`🎊 تهانينا ${winnerMentions}! لقد فزت بـ **${giveaway.prize}**!`);

        const index = global.giveaways.findIndex(g => g.messageId === giveaway.messageId);
        if (index !== -1) {
          global.giveaways[index].ended = true;
          global.giveaways[index].winners = winners.map(w => w.id);
          global.saveGiveaways();
        }
      } catch (error) {
        console.error('Error ending giveaway:', error);
      }
    }, timeInMs);

    message.delete().catch(() => {});
  }
};
