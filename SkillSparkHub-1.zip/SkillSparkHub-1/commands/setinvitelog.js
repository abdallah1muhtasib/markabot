const { PermissionFlagsBits } = require('discord.js');

module.exports = {
  name: 'setinvitelog',
  description: 'تعيين قناة سجل الدعوات',
  permissions: PermissionFlagsBits.ManageGuild,
  async execute(message, args, client) {
    const channel = message.mentions.channels.first() || message.guild.channels.cache.get(args[0]);

    if (!channel) {
      return message.reply('❌ الرجاء منشن القناة أو إدخال ID القناة.\nالاستخدام: `$setinvitelog #channel`');
    }

    if (!global.inviteConfig[message.guild.id]) {
      global.inviteConfig[message.guild.id] = {};
    }

    global.inviteConfig[message.guild.id].logChannelId = channel.id;
    global.saveInviteConfig();

    message.reply(`✅ تم تعيين قناة سجل الدعوات إلى <#${channel.id}>`);
  }
};
