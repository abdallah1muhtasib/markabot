const { PermissionFlagsBits, EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'box',
  description: 'بدء جيف اواي فوري - أول من يتفاعل يفوز',
  permissions: PermissionFlagsBits.ManageGuild,
  async execute(message, args, client) {
    const prize = args.join(' ');

    if (!prize) {
      return message.reply('❌ الاستخدام: `$box <الجائزة>`\nمثال: `$box Discord Nitro`');
    }

    const embed = new EmbedBuilder()
      .setTitle('<:emoji_7:1436089797654351904> جيف اواي فوري <:emoji_7:1436089797654351904>')
      .setDescription(`<:emoji_6:1436085002050732163> *الجائزة:* ${prize}\n\nأول من يتفاعل بـ <:emoji_7:1436089797654351904> يفوز!`)
      .setColor('#6A3FF2')
      .setFooter({ text: `مستضاف بواسطة ${message.author.tag}` })
      .setTimestamp();

    const giveawayMessage = await message.channel.send({ embeds: [embed] });
    await giveawayMessage.react('1436089797654351904');

    const filter = (reaction, user) => {
      return reaction.emoji.id === '1436089797654351904' && !user.bot;
    };

    const collector = giveawayMessage.createReactionCollector({ filter, max: 1, time: 60000 });

    collector.on('collect', async (reaction, user) => {
      const winEmbed = new EmbedBuilder()
        .setTitle('<:emoji_7:1436089797654351904> انتهى الجيف اواي <:emoji_7:1436089797654351904>')
        .setDescription(`**الجائزة:** ${prize}\n**الفائز:** <@${user.id}>`)
        .setColor('#FFD700')
        .setTimestamp();

      await giveawayMessage.edit({ embeds: [winEmbed] });
      await message.channel.send(`🎊 تهانينا <@${user.id}>! لقد فزت بـ **${prize}**!`);
    });

    collector.on('end', async (collected) => {
      if (collected.size === 0) {
        const noWinnerEmbed = new EmbedBuilder()
          .setTitle('<:emoji_7:1436089797654351904> انتهى الجيف اواي <:emoji_7:1436089797654351904>')
          .setDescription(`**الجائزة:** ${prize}\n**الفائز:** لا أحد دخل!`)
          .setColor('#FF0000')
          .setTimestamp();

        await giveawayMessage.edit({ embeds: [noWinnerEmbed] });
      }
    });

    message.delete().catch(() => {});
  }
};
